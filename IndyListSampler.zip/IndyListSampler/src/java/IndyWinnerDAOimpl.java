import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

public class IndyWinnerDAOimpl implements IndyWinnerDAO {
    private static final String DB_URL = "jdbc:mysql://localhost:3306/indywinners";
    private static final String DB_USER = "root";
    private static final String DB_PASSWORD = "krishrose";

    private static final Logger LOGGER = Logger.getLogger(IndyWinnerDAOimpl.class.getName());

    @Override
    public List<IndyWinner> getWinners(int limit, int offset) throws SQLException {
        // Validate input parameters
        if (limit <= 0) throw new IllegalArgumentException("Limit must be greater than 0");
        if (offset < 0) throw new IllegalArgumentException("Offset cannot be negative");

        List<IndyWinner> winners = new ArrayList<>();
        String query = "SELECT year, winnerName, carName FROM IndyWinners ORDER BY year DESC LIMIT ? OFFSET ?";

        // Use try-with-resources to handle database resources
        try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
             PreparedStatement stmt = conn.prepareStatement(query)) {

            stmt.setInt(1, limit);
            stmt.setInt(2, offset);

            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    winners.add(new IndyWinner(
                            rs.getInt("year"),
                            rs.getString("winnerName"),
                            rs.getString("carName")
                    ));
                }
            }
        } catch (SQLException e) {
            // Log SQL exception and rethrow
            LOGGER.log(Level.SEVERE, "Error retrieving winners from database", e);
            throw e;
        }
        return winners;
    }

    @Override
    public int getWinnerCount() throws SQLException {
        String query = "SELECT COUNT(*) FROM IndyWinners";

        try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
             PreparedStatement stmt = conn.prepareStatement(query);
             ResultSet rs = stmt.executeQuery()) {

            if (rs.next()) {
                return rs.getInt(1);
            }
        } catch (SQLException e) {
            // Log SQL exception and rethrow
            LOGGER.log(Level.SEVERE, "Error counting winners in database", e);
            throw e;
        }
        return 0;
    }
}
